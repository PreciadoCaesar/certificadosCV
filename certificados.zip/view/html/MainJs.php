<script src="<?= Conectar::ruta() ?>public/lib/jquery/jquery.js"></script>
<script src="<?= Conectar::ruta() ?>public/lib/popper.js/popper.js"></script>
<script src="<?= Conectar::ruta() ?>public/lib/bootstrap/bootstrap.js"></script>
<script src="<?= Conectar::ruta() ?>public/lib/perfect-scrollbar/js/perfect-scrollbar.jquery.js"></script>
<script src="<?= Conectar::ruta() ?>public/lib/moment/moment.js"></script>
<script src="<?= Conectar::ruta() ?>public/lib/jquery-ui/jquery-ui.js"></script>
<script src="<?= Conectar::ruta() ?>public/lib/jquery-switchbutton/jquery.switchButton.js"></script>
<script src="<?= Conectar::ruta() ?>public/lib/peity/jquery.peity.js"></script>
<script src="<?= Conectar::ruta() ?>public/js/bracket.js"></script>

<script src="<?= Conectar::ruta() ?>public/lib/datatables/jquery.dataTables.js"></script>
<script src="<?= Conectar::ruta() ?>public/lib/datatables-responsive/dataTables.responsive.js"></script>

<script src="<?= Conectar::ruta() ?>public/datatables/dataTables.buttons.min.js"></script>
<script src="<?= Conectar::ruta() ?>public/datatables/buttons.html5.min.js"></script>
<script src="<?= Conectar::ruta() ?>public/datatables/buttons.colVis.min.js"></script>
<script src="<?= Conectar::ruta() ?>public/datatables/jszip.min.js"></script>

<script src="<?= Conectar::ruta() ?>public/lib/select2/js/select2.min.js"></script>

<script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>

<script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.36/pdfmake.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.36/vfs_fonts.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    