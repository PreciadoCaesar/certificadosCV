<!--nuevo -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;700&display=swap" rel="stylesheet">

    <!--<link rel="stylesheet" href="<?php echo Conectar::ruta(); ?>public/css/atomic_design/components/_button.css">-->
    <link rel="stylesheet" href="<?php echo Conectar::ruta(); ?>public/css/atomic_design/components/_input.css">
    <link rel="stylesheet" href="<?php echo Conectar::ruta(); ?>public/css/atomic_design/components/_pagination.css">
    <!--<link rel="stylesheet" href="<?php echo Conectar::ruta(); ?>public/css/atomic_design/components/_table.css">-->

    <link rel="stylesheet" href="<?php echo Conectar::ruta(); ?>public/css/atomic_design/pages/page_template.css">

    <link rel="stylesheet" href="<?php echo Conectar::ruta(); ?>public/css/atomic_design/base.css">
    <link rel="stylesheet" href="<?php echo Conectar::ruta(); ?>public/css/atomic_design/header.css">
    <link rel="stylesheet" href="<?php echo Conectar::ruta(); ?>public/css/atomic_design/layout.css">
    <link rel="stylesheet" href="<?php echo Conectar::ruta(); ?>public/css/atomic_design/sidebar.css">
    <link rel="stylesheet" href="<?php echo Conectar::ruta(); ?>public/css/atomic_design/variables.css">
    <link rel="stylesheet" href="<?php echo Conectar::ruta(); ?>public/css/atomic_design/pages/style.css">
    <link rel="stylesheet" href="<?php echo Conectar::ruta(); ?>public/css/atomic_design/pages/modal_template.css">
    <!--<link rel="stylesheet" href="<?php echo Conectar::ruta(); ?>public/css/atomic_design/pages/page_template.css">-->
    <link rel="stylesheet"
    href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" />
    <link rel="stylesheet" href="https://cdn.datatables.net/buttons/2.4.1/css/buttons.dataTables.min.css">
